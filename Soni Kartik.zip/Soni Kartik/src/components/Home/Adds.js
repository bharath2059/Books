import img1 from './img/1.jpeg'
import img2  from './img/2.jpeg'
import img3 from './img/3.jpeg'
import img4 from './img/4.jpeg'
import img5 from './img/5.jpeg'
import img6 from './img/6.jpeg'
import img7 from './img/7.jpeg'

const Add = [
       {
              img : img1,
              name:'Hansel & Gretel',
              price: 30 
       },
       {
              img : img2,
              name:'Jataka tales',
              price: 37 
       },
       {
              img : img3,
              name:"Grandpa's tales",
              price: 20 
       },
       {
              img : img4,
              name:'The clever fox',
              price: 50 
       },
       {
              img : img5,
              name:'The lazy donkey',
              price: 23 
       },
       {
              img : img6,
              name:'Jungle book',
              price: 30 
       },
       {
              img : img7,
              name:'The Gruffalo',
              price: 10
       },
]

export default Add